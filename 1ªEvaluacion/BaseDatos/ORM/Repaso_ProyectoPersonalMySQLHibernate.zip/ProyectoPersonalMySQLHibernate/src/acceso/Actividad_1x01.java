package acceso;

import java.util.List;
import org.hibernate.HibernateException;
import entrada.Teclado;
import modelo.Departamento;

public class Actividad_1x01 {

	// Escribe en consola el men� de opciones del programa principal.
	public static void escribirMenuOpciones() {
		System.out.println();
		System.out.println("(0) Salir del programa.");
		System.out.println("(1) Insertar un departamento en la base de datos.");
		System.out.println("(2) Consultar todos los departamentos de la base de datos.");
		System.out.println("(3) Consultar un departamento, por c�digo, de la base de datos.");
		System.out.println("(4) Actualizar un departamento, por c�digo, de la base de datos.");
		System.out.println("(5) Eliminar un departamento, por c�digo, de la base de datos.");
		System.out.println();
	}
		
	
	
	// Gestiona los departamentos de la base de datos personal con el men� de opciones:
	// (1) Insertar un departamento en la base de datos.
	// (2) Consultar todos los departamentos de la base de datos.
	// (3) Consultar un departamento, por c�digo, de la base de datos.
	// (4) Actualizar un departamento, por c�digo, de la base de datos.
	// (5) Eliminar un departamento, por c�digo, de la base de datos.
	public static void main(String[] args) {
		int opcion, codigo;
		AccesoDepartamento ad = new AccesoDepartamento();
		do {
			escribirMenuOpciones();
			opcion = Teclado.leerEntero("�Opci�n (0-5)? ");	
			try {
				switch (opcion) {
				// Salir del programa.
				case 0:
					HibernateUtil.closeSessionFactory();
					break;
					
				// Insertar un departamento en la base de datos.
				case 1:
					String nombre = Teclado.leerCadena("Introduce nombre");
					String ubicacion = Teclado.leerCadena("Introduce ubicacion");
					Departamento departamento = new Departamento(nombre, ubicacion);
					ad.insertarUno(departamento);
					
					break;
					
				// Consultar todos los departamentos de la base de datos.
				case 2:
					List<Departamento> todosdepartamentos = ad.consultarTodos();
					for (Departamento departamento2 : todosdepartamentos) {
						System.out.println(departamento2.toString());
					}
					break;
					
				// Consultar un departamento, por c�digo, de la base de datos.
				case 3:
					codigo = Teclado.leerEntero("Introduce codigo");
					Departamento d = ad.consultarUno(codigo);
					if (d != null) {
						d = ad.consultarUno(codigo);
						System.out.println(d.toString());
					} else {
						System.out.println("no existe departamento con ese codigo");
					}
							
					
					
					break;
					
				// Actualizar un departamento, por c�digo, de la base de datos.
				case 4:
					codigo = Teclado.leerEntero("Intoduce codigo del departamento que vas a editar");
					String nombre2 = Teclado.leerCadena("Nuevo nombre:");
					String ubicacion2 = Teclado.leerCadena("Nueva ubicacion:");
					Departamento dep = ad.consultarUno(codigo);
					if (dep != null) {
						Departamento nuevoDepartamento = new Departamento(nombre2, ubicacion2);
						if(ad.actualizarUno( codigo,  nuevoDepartamento)){
							System.out.println("Se ha actualizado un departamento");
						}else {
							System.out.println("No se ha podido editar el departamento");
						}
					} else {
						System.out.println("NO existe ningun departamento con ese codigo");
					}
					
					break;
					
				// Eliminar un departamento, por c�digo, de la base de datos.
				case 5:
					codigo = Teclado.leerEntero("Introduce codigo del departamento que desea eliminar");
					ad.eliminar(codigo);
					break;
					
				// opci�n de men� no v�lida
				default:
					System.out.println("La opci�n de men� debe estar comprendida entre 0 y 5.");
				}
			}
			catch (HibernateException he) {
				System.out.println("Error al acceder a la base de datos MySQL con Hibernate:");
				System.out.println(he.getMessage());
			}
		}
		while (opcion != 0);
		System.out.println("Programa finalizado sin errores.");
	}

}
