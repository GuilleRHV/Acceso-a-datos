package acceso;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.TypedQuery;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import ejemplos.HibernateUtil;
import entrada.Teclado;
import modelo.Departamento;
import modelo.Empleado;

public class AccesoEmpleado {
	
	// Inserta un empleado en la base de datos.
	// Lanza una excepci�n de Hibernate 
	// si ocurre un error al acceder a la base de datos. 
	public static void insertarUno(Empleado empleado)
	throws HibernateException {
		Session sesion = null;
		Transaction transaccion = null;
		try {

			SessionFactory fabricaSesiones = HibernateUtil.getSessionFactory();
			sesion = fabricaSesiones.openSession();
			transaccion = sesion.beginTransaction();

			sesion.save(empleado);
			transaccion.commit();
			System.out.println("Se ha insertado un departamento en la base de datos.");
		}

		finally {
			if (sesion != null) {
				sesion.close();
				// HibernateUtil.closeSessionFactory();
			}
		}
	}
	//(Departamento departamento, String nombre, String fechaAlta, BigDecimal salario
		
	// Consulta todos los empleados de la base de datos.
	// Devuelve una lista de empleados con los resultados.
	// Lanza una excepci�n de Hibernate 
	// si ocurre un error al acceder a la base de datos. 
	public static List<Empleado> consultarTodos()
	throws HibernateException {
		List<Empleado> listaEmpleado = new ArrayList<Empleado>();

		Session sesion = null;
		try {
			SessionFactory fabricaSesiones = HibernateUtil.getSessionFactory();
			sesion = fabricaSesiones.openSession();
			String sentenciaHQL = "select d from Empleado d";
			TypedQuery<Empleado> consulta = sesion.createQuery(sentenciaHQL);// Cumple est�ndar JPA
			listaEmpleado = consulta.getResultList();

		} finally {
			if (sesion != null) {
				sesion.close();
				 //HibernateUtil.closeSessionFactory();
			}
		}

		return listaEmpleado;
	}
	
	// Consulta un empleado, por c�digo, de la base de datos.
	// Devuelve el empleado consultado de la base de datos que tiene un c�digo dado.
	// Devuelve null si no existe ning�n empleado con un c�digo dado.
	// Lanza una excepci�n de Hibernate 
	// si ocurre un error al acceder a la base de datos. 
	public static Empleado consultarUno(int codigo)
	throws HibernateException {
		
		Empleado emp = null;

		Session sesion = null;
		try {
			SessionFactory fabricaSesiones = HibernateUtil.getSessionFactory();
			sesion = fabricaSesiones.openSession();
			emp = sesion.get(Empleado.class, (short) codigo);

		} finally {
			if (sesion != null) {
				sesion.close();
				// HibernateUtil.closeSessionFactory();
			}
		}
		return emp;
	}
	
	// Actualiza un empleado, por c�digo, de la base de datos.
	// Devuelve verdadero si la base de datos contiene un empleado con un c�digo dado y
	// este empleado ha sido actualizado con un nuevo departamento, un nuevo nombre,
	// una nueva fecha de alta y un nuevo salario.
	// Devuelve falso si no existe ning�n empleado con un c�digo dado.
	// Lanza una excepci�n de Hibernate 
	// si ocurre un error al acceder a la base de datos. 
	public static boolean actualizarUno(int codigo, Empleado nuevoEmpleado)
	throws HibernateException {
		
		boolean actualizado = false;
		
		return actualizado;
	}
	
	// Elimina un empleado, por c�digo, de la base de datos.
	// Devuelve verdadero si la base de datos contiene un empleado con un c�digo dado y
	// este empleado ha sido eliminado.
	// Devuelve falso si no existe ning�n departamento con un c�digo dado.
	// Lanza una excepci�n de Hibernate 
	// si ocurre un error al acceder a la base de datos. 
	public static boolean eliminarUno(int codigo)
	throws HibernateException {
		
		boolean eliminado = false;
		
		return eliminado;
	}
		
}
