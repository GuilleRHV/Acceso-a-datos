package acceso;

import java.math.BigDecimal;
import java.util.List;
import org.hibernate.HibernateException;
import entrada.Teclado;
import modelo.Departamento;
import modelo.Empleado;

public class Actividad_1x02 {

	// Escribe en consola el men� de opciones del programa principal.
	public static void escribirMenuOpciones() {
		System.out.println();
		System.out.println("(0) Salir del programa.");
		System.out.println("(1) Insertar un empleado en la base de datos.");
		System.out.println("(2) Consultar todos los empleados de la base de datos.");
		System.out.println("(3) Consultar un empleado, por c�digo, de la base de datos.");
		System.out.println("(4) Actualizar un empleado, por c�digo, de la base de datos.");
		System.out.println("(5) Eliminar un empleado, por c�digo, de la base de datos.");
		System.out.println();
	}

	// Gestiona los empleados de la base de datos personal con el men� de opciones:
	// (1) Insertar un empleado en la base de datos.
	// (2) Consultar todos los empleados de la base de datos.
	// (3) Consultar un empleado, por c�digo, de la base de datos.
	// (4) Actualizar un empleado, por c�digo, de la base de datos.
	// (5) Eliminar un empleado, por c�digo, de la base de datos.
	public static void main(String[] args) {
		int opcion;
		int codigo;
		Departamento departamento;
		Empleado empleado;
		AccesoEmpleado ae = new AccesoEmpleado();
		AccesoDepartamento ad = new AccesoDepartamento();
		do {
			escribirMenuOpciones();
			opcion = Teclado.leerEntero("�Opci�n (0-5)? ");
			try {
				switch (opcion) {
				// Salir del programa.
				case 0:
					HibernateUtil.closeSessionFactory();
					break;

				// Insertar un empleado en la base de datos.
				case 1:
					// (Departamento departamento, String nombre, String fechaAlta, BigDecimal
					// salario
					codigo = Teclado.leerEntero("Introduce codigo del departamento donde quieres ponerlo");
					departamento = ad.consultarUno(codigo);
					System.out.println(departamento.toString());
					if (departamento != null) {
						String nombre = Teclado.leerCadena("Introduce nombre");
						String fechaalta = Teclado.leerCadena("Fecha alta");
						double salario = Teclado.leerReal("Salario");
						// O puedes usar BigDecimal.valueOf(val)
						empleado = new Empleado(departamento, nombre, fechaalta,BigDecimal.valueOf(salario));
						ae.insertarUno(empleado);
					} else {
						System.out.println("No existe ningun departamento con ese codigo");
					}
					break;

				// Consultar todos los empleados de la base de datos.
				case 2:
					//   ae = AccesoEmpleados
						List<Empleado> empleados = ae.consultarTodos();
						System.out.println(empleados.size());
					for (Empleado empleado2 : empleados) {
							System.out.println(empleado2.toString());
						}
					break;

				// Consultar un empleado, por c�digo, de la base de datos.
				case 3:
					codigo = Teclado.leerEntero("Introduce codigo del empleado que quieres buscar");
					empleado = ae.consultarUno(codigo);
					System.out.println(empleado.toString());
					break;

				// Actualizar un empleado, por c�digo, de la base de datos.
				case 4:

					break;

				// Eliminar un empleado, por c�digo, de la base de datos.
				case 5:

					break;

				// opci�n de men� no v�lida
				default:
					System.out.println("La opci�n de men� debe estar comprendida entre 0 y 5.");
				}
			} catch (HibernateException he) {
				System.out.println("Error al acceder a la base de datos MySQL con Hibernate:");
				System.out.println(he.getMessage());
			}
		} while (opcion != 0);
		System.out.println("Programa finalizado sin errores.");
	}

}
