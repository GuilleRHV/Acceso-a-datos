package acceso;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.TypedQuery;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import modelo.Departamento;

public class AccesoDepartamento {
	
	// Inserta un departamento en la base de datos.
	// Lanza una excepci�n de Hibernate 
	// si ocurre un error al acceder a la base de datos. 
	public static void insertarUno(Departamento departamento)
	throws HibernateException {
		
	}
	
	// Consulta todos los departamentos de la base de datos.
	// Devuelve una lista de departamentos con los resultados.
	// Lanza una excepci�n de Hibernate 
	// si ocurre un error al acceder a la base de datos. 
	public static List<Departamento> consultarTodos()
	throws HibernateException {
		
		List<Departamento> listaDepartamentos = new ArrayList<Departamento>();


		return listaDepartamentos;
	}
	
	// Consulta un departamento, por c�digo, de la base de datos.
	// Devuelve el departamento consultado de la base de datos que tiene un c�digo dado.
	// Devuelve null si no existe ning�n departamento con un c�digo dado.
	// Lanza una excepci�n de Hibernate 
	// si ocurre un error al acceder a la base de datos. 
	public static Departamento consultarUno(int codigo)
	throws HibernateException {
		
		Departamento departamento = null;
		
		return departamento;
	}
		
	// Actualiza un departamento, por c�digo, de la base de datos.
	// Devuelve verdadero si la base de datos contiene un departamento con un c�digo dado y
	// este departamento ha sido actualizado con un nuevo nombre y una nueva ubicaci�n.
	// Devuelve falso si no existe ning�n departamento con un c�digo dado.
	// Lanza una excepci�n de Hibernate 
	// si ocurre un error al acceder a la base de datos. 
	public static boolean actualizarUno(int codigo, Departamento nuevoDepartamento)
	throws HibernateException {
		
		boolean actualizado = false;
		
		return actualizado;
	}
	
	// Elimina un departamento, por c�digo, de la base de datos.
	// Devuelve verdadero si la base de datos contiene un departamento con un c�digo dado y
	// este departamento ha sido eliminado.
	// Devuelve falso si no existe ning�n departamento con un c�digo dado.
	// Lanza una excepci�n de Hibernate 
	// si ocurre un error al acceder a la base de datos. 
	public static boolean eliminar(int codigo)
	throws HibernateException {
	
		boolean eliminado = false;
		
		return eliminado;
	}
		
}
